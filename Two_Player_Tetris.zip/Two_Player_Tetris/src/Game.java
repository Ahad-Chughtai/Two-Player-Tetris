import javax.swing.JFrame;
import javax.swing.JLabel;

public class Game
{
    static GamePanel gp;
    static JLabel p1Level = new JLabel("Level 1");
    static JLabel p2Level = new JLabel("Level 1");
    static JLabel p1Score = new JLabel("Score: 0");
    static JLabel p2Score = new JLabel("Score: 0");
    static JLabel p1Hold = new JLabel("Holding: null");
    static JLabel p2Hold = new JLabel("Holding: null");
    static JLabel p1Energy = new JLabel("Energy = 0");
    static JLabel p2Energy = new JLabel("Energy = 0");
    static JLabel p1Speed = new JLabel("Speed: 500");
    static JLabel p2Speed = new JLabel("Speed: 500");

    public void gameStart()
    {
        //Frame
        JFrame mainFrame = new JFrame();
        mainFrame.setVisible(true);
        mainFrame.setTitle("Tetris");
        mainFrame.setBounds(50, 0, 1300, 735);
        mainFrame.setLayout(null);

        //Labels
        JLabel p1Name = new JLabel("P1");
        JLabel p2Name = new JLabel("P2");
        JLabel BombPow = new JLabel("Bomb - 2 Energy");
        JLabel RotatePow = new JLabel("No Rotation - 4 Energy");
        JLabel SpeedPow = new JLabel("Speedup - 6 Energy");
        p1Name.setBounds(535, 0, 20, 20);
        p2Name.setBounds(745, 0, 20, 20);
        p1Level.setBounds(535, 35, 60, 20);
        p2Level.setBounds(715, 35, 60, 20);
        p1Score.setBounds(535, 75, 60, 20);
        p2Score.setBounds(710, 75, 60, 20);
        p1Hold.setBounds(530, 115, 150, 20);
        p2Hold.setBounds(665, 115, 155, 20);
        p1Energy.setBounds(530, 550, 100, 20);
        p2Energy.setBounds(692, 550, 100, 20);
        BombPow.setBounds(600, 595, 130, 20);
        RotatePow.setBounds(576, 625, 160, 20);
        SpeedPow.setBounds(589, 655, 150, 20);
        p1Speed.setBounds(530, 140, 150, 20);
        p2Speed.setBounds(690, 140, 150, 20);


        mainFrame.add( p1Name );
        mainFrame.add( p2Name );
        mainFrame.add( p1Level );
        mainFrame.add( p2Level );
        mainFrame.add( p1Score );
        mainFrame.add( p2Score );
        mainFrame.add( p1Hold );
        mainFrame.add( p2Hold );
        mainFrame.add( p1Energy );
        mainFrame.add( p2Energy );
        mainFrame.add( BombPow );
        mainFrame.add( RotatePow );
        mainFrame.add( SpeedPow );
        mainFrame.add( p1Speed );
        mainFrame.add( p2Speed );

        //Panels
        GamePanel2 gp2 = new GamePanel2();
        new Thread2(gp2).start();

        gp = new GamePanel(gp2);
        new Thread1(gp).start();

        mainFrame.add( gp );
        mainFrame.add( gp2 );

        System.out.print("Press ASD to move Player 1. Press the arrow keys to move Player 2.\n\nTo rotate, press W for Player 1 or the up arrow key for Player 2.\n\nIf you want to slowly descend a block press Shift for Player 1 or Controlfor Player 2. Hold Shift or Control down to move the block left or right and fit it into a spot\n\nIf you want to hold a block for later press Q for Player 1 or Enter for Player 2\n\nPress 1, 2, 3 for Player 1 powerups or 8, 9, 0 for your Player 2 powerups\n\nYou can use powerups if you have enough Energy (you get energy from scoring)\n\nEnjoy :)");
    }

    public void gpAddLine()
    {
        gp.addLine();
    }

    public void updateLevel(int player, int level)
    {
        if (player == 1)
        {
            p1Level.setText("Level " + level);
        }
        else
        {
            p2Level.setText("Level " + level);
        }
    }

    public void updateScore(int player, int score)
    {
        if (player == 1)
        {
            p1Score.setText("Score: " + score);
        }
        else
        {
            p2Score.setText("Score: " + score);
        }
    }

    public void updateHold(int player, int block)
    {
        if (block == 1)
        {
            if (player == 1)
            {
                p1Hold.setText("Holding: ZBlock");
            }
            else
            {
                p2Hold.setText("Holding: ZBlock");
            }
        }
        if (block == 2)
        {
            if (player == 1)
            {
                p1Hold.setText("Holding: SBlock");
            }
            else
            {
                p2Hold.setText("Holding: SBlock");
            }
        }
        if (block == 3)
        {
            if (player == 1)
            {
                p1Hold.setText("Holding: LBlock");
            }
            else
            {
                p2Hold.setText("Holding: LBlock");
            }
        }
        if (block == 4)
        {
            if (player == 1)
            {
                p1Hold.setText("Holding: JBlock");
            }
            else
            {
                p2Hold.setText("Holding: JBlock");
            }
        }
        if (block == 5)
        {
            if (player == 1)
            {
                p1Hold.setText("Holding: TBlock");
            }
            else
            {
                p1Hold.setText("Holding: TBlock");
            }
        }
        if (block == 6)
        {
            if (player == 1)
            {
                p1Hold.setText("Holding: IBlock");
            }
            else
            {
                p2Hold.setText("Holding: IBlock");
            }
        }
        if (block == 7)
        {
            if (player == 1)
            {
                p1Hold.setText("Holding: OBlock");
            }
            else
            {
                p2Hold.setText("Holding: OBlock");
            }
        }
        if (block == 8)
        {
            if (player == 1)
            {
                p1Hold.setText("Holding: Bomb");
            }
            else
            {
                p2Hold.setText("Holding: Bomb");
            }
        }
    }

    public void updateEnergy(int player, int energy)
    {
        if (player == 1)
        {
            p1Energy.setText("Energy = " + energy);
        }
        else
        {
            p2Energy.setText("Energy = " + energy);
        }
    }

    public void updateSpeed(int player, int speed)
    {
        if (player == 1)
        {
            p1Speed.setText("Speed: " + speed);
        }
        else
        {
            p2Speed.setText("Speed: " + speed);
        }
    }

    public static void main(String[] args)
    {
        Game g = new Game();
        g.gameStart();
    }
}