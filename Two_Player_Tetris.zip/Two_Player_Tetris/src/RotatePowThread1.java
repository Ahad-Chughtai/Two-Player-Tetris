public class RotatePowThread1 extends Thread
{
    GamePanel gp;

    RotatePowThread1(GamePanel gp)
    {
        this.gp = gp;
    }

    public void run()
    {
        try
        {
            System.out.println("\n\nP1 Can't Rotate for 30 seconds!");
            Thread.sleep(30000);
            gp.rotateEnabled = true;
        }
        catch (Exception ex)
        {
        }
    }
}