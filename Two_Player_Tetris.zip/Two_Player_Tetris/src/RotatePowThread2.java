public class RotatePowThread2 extends Thread
{
    GamePanel2 gp2;

    RotatePowThread2(GamePanel2 gp2)
    {
        this.gp2 = gp2;
    }

    public void run()
    {
        try
        {
            System.out.println("\n\nP2 Can't Rotate for 30 seconds!");
            Thread.sleep(30000);
            gp2.rotateEnabled = true;
        }
        catch (Exception ex)
        {
        }
    }
}