import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import java.util.ArrayList;

public class GamePanel extends JPanel implements KeyListener
{
    Game g = new Game();
    GamePanel2 gp2;

    Color lightGray = new Color(211, 211, 211);
    Color darkGray = new Color(169, 169, 169);
    Color darkRed = new Color(139, 0, 0);
    Color blockColor;
    Color heldColor;
    Color heldColor2;

    Random rand = new Random();

    int panelColumns = 15;
    int panelRows;
    int panelSquares;
    int y;
    int x;
    int blockCode;
    int heldBlockCode;
    int heldBlockCode2;
    int rotation;
    int score = 0;
    int energy = 0;

    boolean shiftMove;
    boolean rotateEnabled = true;
    boolean speedPow = false;


    int[][] SBlock = {
            {1, 0},
            {1, 1},
            {0, 1}
    };

    int[][] SBlockR1 = {
            {0, 1, 1},
            {1, 1, 0}
    };

    int[][] ZBlock = {
            {0, 1},
            {1, 1},
            {1, 0}
    };

    int[][] ZBlockR1 = {
            {1, 1, 0},
            {0, 1, 1}
    };

    int[][] LBlock = {
            {1, 0},
            {1, 0},
            {1, 1}
    };

    int[][] LBlockR1 = {
            {1, 1, 1},
            {1, 0, 0}
    };

    int[][] LBlockR2 = {
            {1, 1},
            {0, 1},
            {0, 1}
    };

    int[][] LBlockR3 = {
            {0, 0, 1},
            {1, 1, 1}
    };

    int[][] JBlock = {
            {0, 1},
            {0, 1},
            {1, 1}
    };

    int[][] JBlockR1 = {
            {1, 0, 0},
            {1, 1, 1}
    };

    int[][] JBlockR2 = {
            {1, 1},
            {1, 0},
            {1, 0}
    };

    int[][] JBlockR3 = {
            {1, 1, 1},
            {0, 0, 1}
    };

    int[][] TBlock = {
            {0, 1, 0},
            {1, 1, 1}
    };

    int[][] TBlockR1 = {
            {1, 0},
            {1, 1},
            {1, 0}
    };

    int[][] TBlockR2 = {
            {1, 1, 1},
            {0, 1, 0}
    };

    int[][] TBlockR3 = {
            {0, 1},
            {1, 1},
            {0, 1}
    };

    int[][] IBlock =
            {
                    {1},
                    {1},
                    {1},
                    {1}
            };

    int[][] IBlockR1 =
            {
                    {1, 1, 1, 1}
            };

    int[][] OBlock = {
            {1, 1},
            {1, 1}
    };

    int[][] bombBlock = {
            {1}
    };

    int[][] gameBoard = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    };

    int[][] currentBlock;
    int[][] heldBlock;
    int[][] heldBlock2;

    GamePanel(GamePanel2 gp2)
    {
        addKeyListener(this);
        setFocusable(true);

        this.gp2 = gp2;

        setBorder(BorderFactory.createLineBorder(Color.black));
        setBackground(lightGray);
        setBounds(25, 0, 496, 695);

        panelSquares = 500 / panelColumns;
        panelRows = 700 / panelSquares;
    }

    public void paintComponent(Graphics g)
    {
        requestFocus(true);
        super.paintComponent(g);

        for (int i = 0; i < panelRows; i++)
        {
            for (int j = 0; j < panelColumns; j++)
            {
                g.setColor(Color.WHITE);
                g.drawRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
            }
        }

        drawBlock(g);
    }

    //makes currentBlock into random block in the code
    public void newBlock()
    {
        int randBlock = rand.nextInt(7);

        if (randBlock == 1)
        {
            blockColor = (Color.red);
            currentBlock = ZBlock;
            blockCode = 1;
        }
        else if (randBlock == 2)
        {
            blockColor = (Color.green);
            currentBlock = SBlock;
            blockCode = 2;
        }
        else if (randBlock == 3)
        {
            blockColor = (Color.orange);
            currentBlock = LBlock;
            blockCode = 3;
        }
        else if (randBlock == 4)
        {
            blockColor = (Color.blue);
            currentBlock = JBlock;
            blockCode = 4;
        }
        else if (randBlock == 5)
        {
            blockColor = new Color(204, 0, 204);
            currentBlock = TBlock;
            blockCode = 5;
        }
        else if (randBlock == 6)
        {
            blockColor = new Color(0, 255, 255);
            currentBlock = IBlock;
            blockCode = 6;
        }
        else
        {
            blockColor = (Color.yellow);
            currentBlock = OBlock;
            blockCode = 7;
        }

        y = -1;
        x = 6;
        rotation = 0;
    }

    //draws whatever currentblock is
    public void drawBlock(Graphics g)
    {
        //draws the block
        for (int i = 0; i < currentBlock.length; i++)
        {
            for (int j = 0; j < currentBlock[0].length; j++)
            {
                if (blockCode == 8)
                {
                    g.setColor(blockColor);
                    g.fillRect((j + x) * panelSquares, (i + y) * panelSquares, panelSquares, panelSquares);
                    g.setColor(Color.black);
                    g.drawRect((j + x) * panelSquares, (i + y) * panelSquares, panelSquares, panelSquares);
                }
                else if (currentBlock[i][j] == 1)
                {
                    g.setColor(blockColor);
                    g.fillRect((j + x) * panelSquares, (i + y) * panelSquares, panelSquares, panelSquares);
                    g.setColor(Color.black);
                    g.drawRect((j + x) * panelSquares, (i + y) * panelSquares, panelSquares, panelSquares);
                }
            }
        }

        //draws the gameboard 
        for (int i = 0; i < gameBoard.length; i++)
        {
            for (int j = 0; j < gameBoard[0].length; j++)
            {
                if (gameBoard[i][j] == 1)
                {
                    g.setColor(Color.red);
                    g.fillRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                    g.setColor(Color.black);
                    g.drawRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                }
                if (gameBoard[i][j] == 2)
                {
                    g.setColor(Color.green);
                    g.fillRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                    g.setColor(Color.black);
                    g.drawRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                }
                if (gameBoard[i][j] == 3)
                {
                    g.setColor(Color.orange);
                    g.fillRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                    g.setColor(Color.black);
                    g.drawRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                }
                if (gameBoard[i][j] == 4)
                {
                    g.setColor(Color.blue);
                    g.fillRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                    g.setColor(Color.black);
                    g.drawRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                }
                if (gameBoard[i][j] == 5)
                {
                    g.setColor( new Color (204, 0, 204) );
                    g.fillRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                    g.setColor(Color.black);
                    g.drawRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                }
                if (gameBoard[i][j] == 6)
                {
                    g.setColor( new Color(0, 255, 255) );
                    g.fillRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                    g.setColor(Color.black);
                    g.drawRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                }
                if (gameBoard[i][j] == 7)
                {
                    g.setColor(Color.yellow);
                    g.fillRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                    g.setColor(Color.black);
                    g.drawRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                }
                if (gameBoard[i][j] == 9)
                {
                    g.setColor(Color.darkGray);
                    g.fillRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                    g.setColor(Color.black);
                    g.drawRect(j * panelSquares, i * panelSquares, panelSquares, panelSquares);
                }
            }
        }
    }

    public void updateGameBoard()
    {
        for (int i = 0; i < currentBlock.length; i++)
        {
            for (int j = 0; j < currentBlock[0].length; j++)
            {
                if (blockCode == 8)
                {
                    if (x == 0)
                    {
                        gameBoard[i+y][j+x] = 0;
                        gameBoard[i+y+1][j+x] = 0;
                        gameBoard[i+y+1][j+x+1] = 0;
                        gameBoard[i+y][j+x+1] = 0;
                        gameBoard[i+y-1][j+x] = 0;
                        gameBoard[i+y-1][j+x+1] = 0;
                    }
                    else if (x + currentBlock.length == gameBoard[0].length)
                    {
                        gameBoard[i+y][j+x] = 0;
                        gameBoard[i+y+1][j+x] = 0;
                        gameBoard[i+y+1][j+x-1] = 0;
                        gameBoard[i+y][j+x-1] = 0;
                        gameBoard[i+y-1][j+x] = 0;
                        gameBoard[i+y-1][j+x-1] = 0;
                    }
                    else if (y + currentBlock.length == gameBoard.length)
                    {
                        gameBoard[i+y][j+x] = 0;
                        gameBoard[i+y][j+x-1] = 0;
                        gameBoard[i+y][j+x+1] = 0;
                        gameBoard[i+y-1][j+x] = 0;
                        gameBoard[i+y-1][j+x-1] = 0;
                        gameBoard[i+y-1][j+x+1] = 0;
                    }
                    else
                    {
                        gameBoard[i+y][j+x] = 0;
                        gameBoard[i+y-1][j+x] = 0;
                        gameBoard[i+y-1][j+x-1] = 0;
                        gameBoard[i+y-1][j+x+1] = 0;
                        gameBoard[i+y][j+x+1] = 0;
                        gameBoard[i+y][j+x-1] = 0;
                        gameBoard[i+y+1][j+x] = 0;
                        gameBoard[i+y+1][j+x-1] = 0;
                        gameBoard[i+y+1][j+x+1] = 0;
                    }
                }
                else if (currentBlock[i][j] == 1)
                {
                    gameBoard[i+y][j+x] = blockCode;
                }
            }
        }

        lineCheck();

        /*
        for (int i = 0; i < gameBoard.length; i++)
        {
            for (int j = 0; j < gameBoard[0].length; j++)
            {
                System.out.print(gameBoard[i][j]);
            }
                System.out.println("");
        }
        */
    }

    public void lineCheck()
    {
        ArrayList<Integer> line = new ArrayList<Integer>();
        boolean lineIsFilled = false;
        boolean lastLine = true;
        boolean grayLine = false;

        for (int i = 0; i < gameBoard.length; i++)
        {
            for (int j = 0; j < gameBoard[0].length; j++)
            {
                if (gameBoard[i][j] == 0 || gameBoard[i][j] == 9)
                {
                    if (i != 20)
                    {
                        i++;
                        j = 0;
                    }
                    else
                    {
                        lastLine = false;
                    }
                }

                if (j == 14 && lastLine)
                {
                    line.add(i);

                    if (i != 20)
                    {
                        if (gameBoard[i+1][j] == 9)
                        {
                            line.add(i+1);
                        }

                        i++;
                        j = 0;
                    }

                    lineIsFilled = true;
                }
            }
        }

        if (lineIsFilled)
        {
            for (int h = 0; h < line.size(); h++)
            {
                for (int i = line.get(h); i > 0; i--)
                {
                    for (int j = 0; j < gameBoard[0].length; j++)
                    {
                        if (gameBoard[i][j] == 9)
                        {
                            grayLine = true;
                        }

                        gameBoard[i][j] = gameBoard[i-1][j];
                    }
                }

                if (grayLine == false)
                {
                    gp2.addLine();
                    score++;
                    energy++;
                }
                else
                {
                    grayLine = false;
                }
            }

            g.updateScore(1, score);
            g.updateEnergy(1, energy);
        }
    }

    public void addLine()
    {
        for (int i = 0; i < gameBoard.length; i++)
        {
            for (int j = 0; j < gameBoard[0].length; j++)
            {
                if (i == 20)
                {
                    gameBoard[i][j] = 9;
                }
                else
                {
                    gameBoard[i][j] = gameBoard[i+1][j];
                }
            }
        }
    }

    public boolean gameOverCheck()
    {
        for (int i = 0; i < gameBoard[0].length; i++)
        {
            if (gameBoard[0][i] != 0)
            {
                return false;
            }
        }

        return true;
    }

    public boolean moveDownCheck()
    {
        if (y + currentBlock.length != panelRows)
        {
            if (y < 0)
            {
                return true;
            }

            for (int i = 0; i < currentBlock.length; i++)
            {
                for (int j = 0; j < currentBlock[0].length; j++)
                {
                    if (currentBlock[i][j] == 1)
                    {
                        if (gameBoard[i+y+1][j+x] != 0)
                        {
                            return false;
                        }
                    }
                }
            }
        }
        else
        {
            return false;
        }

        return true;
    }

    public boolean checkLeft()
    {
        for (int i = 0; i < currentBlock.length; i++)
        {
            for (int j = 0; j < currentBlock[0].length; j++)
            {
                if (currentBlock[i][j] == 1)
                {
                    if (gameBoard[i+y][j+x-1] != 0)
                    {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    public boolean checkRight()
    {
        for (int i = 0; i < currentBlock.length; i++)
        {
            for (int j = 0; j < currentBlock[0].length; j++)
            {
                if (currentBlock[i][j] == 1)
                {
                    if (gameBoard[i+y][j+x+1] != 0)
                    {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    public void holdBlock()
    {
        if (heldBlock == null)
        {
            heldBlock = currentBlock;
            heldColor = blockColor;
            heldBlockCode = blockCode;
            newBlock();
        }
        else
        {
            heldBlock2 = currentBlock;
            heldColor2 = blockColor;
            heldBlockCode2 = blockCode;

            currentBlock = heldBlock;
            blockColor = heldColor;
            blockCode = heldBlockCode;

            heldBlock = heldBlock2;
            heldColor = heldColor2;
            heldBlockCode = heldBlockCode2;

            repaint();
        }

        g.updateHold(1, heldBlockCode);
    }

    public void rotateBlock()
    {
        if (blockCode == 1)
        {
            rotation++;

            if (rotation == 1 && x + ZBlockR1[0].length <= gameBoard[0].length)
            {
                if (checkRight() || y < 0)
                {
                    currentBlock = ZBlockR1;
                    repaint();
                }
            }
            else if (rotation == 2)
            {
                rotation = 0;

                currentBlock = ZBlock;
                repaint();
            }
            else
            {
                rotation--;
            }
        }
        else if (blockCode == 2)
        {
            rotation++;

            if (rotation == 1 && x + SBlockR1[0].length <= gameBoard[0].length)
            {
                if (checkRight() || y < 0)
                {
                    currentBlock = SBlockR1;
                    repaint();
                }
            }
            else if (rotation == 2)
            {
                rotation = 0;

                currentBlock = SBlock;
                repaint();
            }
            else
            {
                rotation--;
            }
        }
        else if (blockCode == 3)
        {
            rotation++;

            if (rotation == 1 && x + LBlockR1[0].length <= gameBoard[0].length)
            {
                if (checkRight() || y < 0)
                {
                    currentBlock = LBlockR1;
                    repaint();
                }
            }
            else if (rotation == 2)
            {
                currentBlock = LBlockR2;
                repaint();
            }
            else if (rotation == 3 && x + LBlockR3[0].length <= gameBoard[0].length)
            {
                if (checkRight() || y < 0)
                {
                    currentBlock = LBlockR3;
                    repaint();
                }
            }
            else if (rotation == 4)
            {
                rotation = 0;

                currentBlock = LBlock;
                repaint();
            }
            else
            {
                rotation--;
            }
        }
        else if (blockCode == 4)
        {
            rotation++;

            if (rotation == 1 && x + JBlockR1[0].length <= gameBoard[0].length)
            {
                if (checkRight() || y < 0)
                {
                    currentBlock = JBlockR1;
                    repaint();
                }
            }
            else if (rotation == 2)
            {
                currentBlock = JBlockR2;
                repaint();
            }
            else if (rotation == 3 && x + JBlockR3[0].length <= gameBoard[0].length)
            {
                if (checkRight() || y < 0)
                {
                    currentBlock = JBlockR3;
                    repaint();
                }
            }
            else if (rotation == 4)
            {
                rotation = 0;

                currentBlock = JBlock;
                repaint();
            }
            else
            {
                rotation--;
            }
        }
        else if (blockCode == 5)
        {
            rotation++;

            if (rotation == 1)
            {
                currentBlock = TBlockR1;
                repaint();
            }
            else if (rotation == 2 && x + TBlockR2[0].length <= gameBoard[0].length)
            {
                if (checkRight() || y < 0)
                {
                    currentBlock = TBlockR2;
                    repaint();
                }
            }
            else if (rotation == 3)
            {
                currentBlock = TBlockR3;
                repaint();
            }
            else if (rotation == 4 && x + TBlock[0].length <= gameBoard[0].length)
            {
                rotation = 0;

                currentBlock = TBlock;
                repaint();
            }
            else
            {
                rotation--;
            }
        }
        else if (blockCode == 6)
        {
            rotation++;

            if (rotation == 1 && x + IBlockR1[0].length <= gameBoard[0].length)
            {
                if (checkRight() || y < 0)
                {
                    currentBlock = IBlockR1;
                    repaint();
                }
            }
            else if (rotation == 2)
            {
                rotation = 0;

                currentBlock = IBlock;
                repaint();
            }
            else
            {
                rotation--;
            }
        }
    }

    public void keyPressed(KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_W && rotateEnabled && moveDownCheck())
        {
            rotateBlock();
        }
        else if (e.getKeyCode() == KeyEvent.VK_A && x > 0 && checkLeft())
        {
            if (shiftMove)
            {
                x--;
                repaint();
            }
            else if (moveDownCheck())
            {
                x--;
                repaint();
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_D && x + currentBlock[0].length < gameBoard[0].length && checkRight())
        {
            if (shiftMove)
            {
                x++;
                repaint();
            }
            else if (moveDownCheck())
            {
                x++;
                repaint();
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_S)
        {
            while (moveDownCheck())
            {
                y++;
                repaint();
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_SHIFT)
        {
            shiftMove = true;

            if (moveDownCheck())
            {
                y++;

                if (moveDownCheck())
                {
                    y++;
                    repaint();
                }

                repaint();
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_1 && moveDownCheck())
        {
            if (energy >= 2)
            {
                currentBlock = bombBlock;
                blockCode = 8;
                blockColor = (darkRed);
                repaint();
                energy -= 2;
                g.updateEnergy(1, energy);
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_2 && gp2.rotateEnabled)
        {
            if (energy >= 4)
            {
                gp2.rotateEnabled = false;
                new RotatePowThread2(gp2).start();
                energy -= 4;
                g.updateEnergy(1, energy);
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_3 && gp2.speedPow == false)
        {
            if (energy >= 6)
            {
                gp2.speedPow = true;
                energy -= 6;
                g.updateEnergy(1, energy);
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_Q && moveDownCheck())
        {
            holdBlock();
        }
        // GamePanel2 Keys      
        else if (e.getKeyCode() == KeyEvent.VK_UP && gp2.rotateEnabled && gp2.moveDownCheck())
        {
            gp2.rotateBlock();
        }
        else if (e.getKeyCode() == KeyEvent.VK_LEFT && gp2.x > 0 && gp2.checkLeft())
        {
            if (gp2.shiftMove)
            {
                gp2.x--;
                gp2.repaint();
            }
            else if (gp2.moveDownCheck())
            {
                gp2.x--;
                gp2.repaint();
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_RIGHT && gp2.x + gp2.currentBlock[0].length < gp2.gameBoard[0].length && gp2.checkRight())
        {
            if (gp2.shiftMove)
            {
                gp2.x++;
                gp2.repaint();
            }
            else if (gp2.moveDownCheck())
            {
                gp2.x++;
                gp2.repaint();
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_DOWN)
        {
            while (gp2.moveDownCheck())
            {
                gp2.y++;
                gp2.repaint();
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_CONTROL)
        {
            gp2.shiftMove = true;

            if (gp2.moveDownCheck())
            {
                gp2.y++;

                if (gp2.moveDownCheck())
                {
                    gp2.y++;
                    gp2.repaint();
                }

                gp2.repaint();
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_8 && gp2.moveDownCheck())
        {
            if (gp2.energy >= 2)
            {
                gp2.currentBlock = bombBlock;
                gp2.blockCode = 8;
                gp2.blockColor = (darkRed);
                gp2.repaint();
                gp2.energy -= 2;
                g.updateEnergy(2, gp2.energy);
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_9 && rotateEnabled)
        {
            if (gp2.energy >= 4)
            {
                rotateEnabled = false;
                new RotatePowThread1(g.gp).start();
                gp2.energy -= 4;
                g.updateEnergy(2, gp2.energy);
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_0 && speedPow == false)
        {
            if (gp2.energy >= 6)
            {
                speedPow = true;
                gp2.energy -= 6;
                g.updateEnergy(2, gp2.energy);
            }
        }
        else if (e.getKeyCode() == KeyEvent.VK_ENTER && gp2.moveDownCheck())
        {
            gp2.holdBlock();
        }
    }
    public void keyReleased(KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_SHIFT)
        {
            shiftMove = false;
        }
        else if (e.getKeyCode() == KeyEvent.VK_CONTROL)
        {
            gp2.shiftMove = false;
        }
    }
    public void keyTyped(KeyEvent e)
    {
    }
}