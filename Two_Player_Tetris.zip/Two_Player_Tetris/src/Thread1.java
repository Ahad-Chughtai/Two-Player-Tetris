public class Thread1 extends Thread
{
    Game g = new Game();
    GamePanel gp;
    int threadSpeed = 500;

    Thread1(GamePanel gp)
    {
        this.gp = gp;
    }

    public void run()
    {
        do
        {
            gp.newBlock();

            while (gp.moveDownCheck())
            {
                try
                {
                    if (gp.speedPow)
                    {
                        System.out.println("\n\nP1's speed is super fast until they reach a new level!");
                        threadSpeed -= 250;
                        gp.speedPow = false;
                        g.updateSpeed(1, threadSpeed);
                    }

                    gp.y++;
                    gp.repaint();
                    Thread.sleep(threadSpeed);
                }
                catch (Exception ex)
                {
                }
            }

            gp.updateGameBoard();

            if (gp.score == 5)
            {
                threadSpeed = 400;
                g.updateLevel(1, 2);
                g.updateSpeed(1, threadSpeed);
            }
            else if (gp.score == 10)
            {
                threadSpeed = 300;
                g.updateLevel(1, 3);
                g.updateSpeed(1, threadSpeed);
            }
            else if (gp.score == 15)
            {
                threadSpeed = 250;
                g.updateLevel(1, 4);
                g.updateSpeed(1, threadSpeed);
            }
            else if (gp.score == 20)
            {
                threadSpeed = 200;
                g.updateLevel(1, 5);
                g.updateSpeed(1, threadSpeed);
            }
            else if (gp.score == 25)
            {
                threadSpeed = 150;
                g.updateLevel(1, 6);
                g.updateSpeed(1, threadSpeed);
            }
            else if (gp.score == 30)
            {
                threadSpeed = 100;
                g.updateLevel(1, 7);
                g.updateSpeed(1, threadSpeed);
            }
            else if (gp.score == 40)
            {
                threadSpeed = 50;
                g.updateLevel(1, 8);
                g.updateSpeed(1, threadSpeed);
            }

        } while (gp.gameOverCheck());
    }
}