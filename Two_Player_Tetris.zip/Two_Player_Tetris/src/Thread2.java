public class Thread2 extends Thread
{
    Game g = new Game();
    GamePanel2 gp2;
    int threadSpeed = 500;

    Thread2(GamePanel2 gp2)
    {
        this.gp2 = gp2;
    }

    public void run()
    {
        do
        {
            gp2.newBlock();

            while (gp2.moveDownCheck())
            {
                try
                {
                    if (gp2.speedPow)
                    {
                        System.out.println("\n\nP2's speed is super fast until they reach a new level!");
                        threadSpeed -= 250;
                        gp2.speedPow = false;
                        g.updateSpeed(2, threadSpeed);
                    }

                    gp2.y++;
                    gp2.repaint();
                    Thread.sleep(threadSpeed);
                }
                catch (Exception ex)
                {
                }
            }

            gp2.updateGameBoard();

            if (gp2.score == 5)
            {
                g.updateLevel(2, 2);
                threadSpeed = 400;
                g.updateSpeed(2, threadSpeed);
            }
            else if (gp2.score == 10)
            {
                threadSpeed = 300;
                g.updateLevel(2, 3);
                g.updateSpeed(2, threadSpeed);
            }
            else if (gp2.score == 15)
            {
                threadSpeed = 250;
                g.updateLevel(2, 4);
                g.updateSpeed(2, threadSpeed);
            }
            else if (gp2.score == 20)
            {
                threadSpeed = 200;
                g.updateLevel(2, 5);
                g.updateSpeed(2, threadSpeed);
            }
            else if (gp2.score == 25)
            {
                threadSpeed = 150;
                g.updateLevel(2, 6);
                g.updateSpeed(2, threadSpeed);
            }
            else if (gp2.score == 30)
            {
                threadSpeed = 100;
                g.updateLevel(2, 7);
                g.updateSpeed(2, threadSpeed);
            }
            else if (gp2.score == 40)
            {
                threadSpeed = 50;
                g.updateLevel(2, 8);
                g.updateSpeed(2, threadSpeed);
            }

        } while (gp2.gameOverCheck());
    }
}